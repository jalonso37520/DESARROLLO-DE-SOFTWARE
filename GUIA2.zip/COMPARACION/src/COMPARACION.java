public class COMPARACION {    
    public static int obtenerMayor(int valor1, int valor2) {
        if (valor1 > valor2) {
            return valor1;
        } else {
            return valor2;
        }
    }    
    public static void main(String[] args) {
        java.util.Scanner entrada = new java.util.Scanner(System.in);       
        System.out.print("Ingrese el primer número entero: ");
        int numeroA = entrada.nextInt();        
        System.out.print("Ingrese el segundo número entero: ");
        int numeroB = entrada.nextInt();        
        int numeroMayor = obtenerMayor(numeroA, numeroB);       
        System.out.println("El mayor de los dos números es: " + numeroMayor);
    }
}
