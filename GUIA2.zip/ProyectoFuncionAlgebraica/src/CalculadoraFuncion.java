public class CalculadoraFuncion {

    
    public static int calcularFuncion(int x, int y) {
        int resultado = (x * x) + (2 * x * y) + (y * y);
        return resultado;
    }

    public static void main(String[] args) {
        
        int x = 3; 
        int y = 4;

        int resultado = calcularFuncion(x, y);

        System.out.println("El valor de f(" + x + ", " + y + ") es: " + resultado);
    }
}
