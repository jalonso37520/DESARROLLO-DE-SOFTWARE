public class CalculoEscalera {
    
    public static double calcularLongitudEscalera(double altura, double anguloEnGrados) {
    	
        double anguloEnRadianes = Math.toRadians(anguloEnGrados);       
        double longitudEscalera = altura / Math.sin(anguloEnRadianes);
        return longitudEscalera;
    }
    public static void main(String[] args) {        
        double altura = 15.0; 
        double angulo = 40.0;
        double longitud = calcularLongitudEscalera(altura, angulo);
        System.out.println("La longitud de la escalera es: " + longitud + " metros");
    }
}
