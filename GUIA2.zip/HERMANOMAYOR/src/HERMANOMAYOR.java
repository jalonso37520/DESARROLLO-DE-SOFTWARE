
public class HERMANOMAYOR {
      public static String obtenerHermanoMayor(String nombre1, int edad1, String nombre2, int edad2, String nombre3, int edad3) {
        String hermanoMayor;
        if (edad1 >= edad2 && edad1 >= edad3) {
            hermanoMayor = nombre1;
        } else if (edad2 >= edad1 && edad2 >= edad3) {
            hermanoMayor = nombre2;
        } else {
            hermanoMayor = nombre3;
        }
        return hermanoMayor;
    }    
    public static void main(String[] args) {
        java.util.Scanner entrada = new java.util.Scanner(System.in);        
        System.out.print("Ingrese el nombre del primer hermano: ");
        String nombre1 = entrada.nextLine();
        System.out.print("Ingrese la edad del primer hermano: ");
        int edad1 = entrada.nextInt();
        entrada.nextLine();
        System.out.print("Ingrese el nombre del segundo hermano: ");
        String nombre2 = entrada.nextLine();
        System.out.print("Ingrese la edad del segundo hermano: ");
        int edad2 = entrada.nextInt();
        entrada.nextLine();
        System.out.print("Ingrese el nombre del tercer hermano: ");
        String nombre3 = entrada.nextLine();
        System.out.print("Ingrese la edad del tercer hermano: ");
        int edad3 = entrada.nextInt();        
        String hermanoMayor = obtenerHermanoMayor(nombre1, edad1, nombre2, edad2, nombre3, edad3);        
        System.out.println("El hermano mayor es: " + hermanoMayor);
    }
}
