public class GastosPedro {

    public static double calcularGastoArriendo(double sueldo) {
        return sueldo * 0.40;
    }
    
    
    public static double calcularGastoComida(double sueldo) {
        return sueldo * 0.15;
    }
    
    
    public static void main(String[] args) 
    {        
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Ingrese el sueldo de Pedro: ");
        double sueldo = scanner.nextDouble();        
        double gastoArriendo = calcularGastoArriendo(sueldo);
        double gastoComida = calcularGastoComida(sueldo);
        double dineroRestante = sueldo - gastoArriendo - gastoComida;        
        System.out.println("Gasto en arriendo: " + gastoArriendo);
        System.out.println("Gasto en comida: " + gastoComida);
        System.out.println("Dinero restante: " + dineroRestante);
    }
}
