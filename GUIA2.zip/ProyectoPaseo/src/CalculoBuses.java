public class CalculoBuses {

   
    public static int calcularNumeroDeBuses(int sillasPorBus, int estudiantesGordos, int estudiantesFlacos) {
        int sillasOcupadas = (estudiantesGordos * 2) + estudiantesFlacos;
        int numeroDeBuses = (int) Math.ceil((double) sillasOcupadas / sillasPorBus);
        return numeroDeBuses;
    }

    public static void main(String[] args) {
        
        int sillasPorBus = 50; 
        int estudiantesGordos = 300; 
        int estudiantesFlacos = 30; 

        int busesNecesarios = calcularNumeroDeBuses(sillasPorBus, estudiantesGordos, estudiantesFlacos);

        System.out.println("Se necesitan " + busesNecesarios + " buses para llevar a todos los estudiantes al paseo.");
    }
}
