public class AREACIRCULAR {

    
    public static double calcularAreaCirculo(double radio) {
        return Math.PI * Math.pow(radio, 2);
    }    
    public static double calcularAreaCorona(double radioGrande, double radioPequeno) {
        double areaGrande = calcularAreaCirculo(radioGrande);
        double areaPequeno = calcularAreaCirculo(radioPequeno);
        return areaGrande - areaPequeno;
    }
    
    public static void main(String[] args) 
    {        
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Ingrese el radio del círculo grande (R): ");
        double radioGrande = scanner.nextDouble();
        System.out.print("Ingrese el radio del círculo pequeño (r): ");
        double radioPequeno = scanner.nextDouble();
        double areaCorona = calcularAreaCorona(radioGrande, radioPequeno);
        System.out.println("El área de la corona circular es: " + areaCorona);
    }
}
