public class TerrenoInmobiliaria {
 
    public static double calcularAreaRectangulo(double base, double altura) 
    {
        return base * altura;
    }
   
    public static double calcularHipotenusa(double cateto1, double cateto2) 
    {
        return Math.sqrt(Math.pow(cateto1, 2) + Math.pow(cateto2, 2));
    }

        public static double calcularAreaTriangulo(double base, double altura) 
        {
        return 0.5 * base * altura;
    }
    
    public static double calcularPerimetroTerreno(double ladoA, double ladoB, double ladoC)
    {
        double hipotenusa = calcularHipotenusa(ladoA, ladoC);
        return ladoA + ladoB + hipotenusa;
    }    
    public static void main(String[] args) {
        java.util.Scanner scanner = new java.util.Scanner(System.in);        
        System.out.print("Ingrese el valor de A (altura del rectángulo): ");
        double ladoA = scanner.nextDouble();
        System.out.print("Ingrese el valor de B (base del rectángulo): ");
        double ladoB = scanner.nextDouble();
        System.out.print("Ingrese el valor de C (base del triángulo): ");
        double ladoC = scanner.nextDouble();        
        double areaRectangulo = calcularAreaRectangulo(ladoB, ladoA);        
        double areaTriangulo = calcularAreaTriangulo(ladoC, ladoA);        
        double areaTerreno = areaRectangulo + areaTriangulo;        
        double perimetroTerreno = calcularPerimetroTerreno(ladoA, ladoB, ladoC);  
        System.out.println("El área total del terreno es: " + areaTerreno);
        System.out.println("El perímetro total del terreno es: " + perimetroTerreno);
    }
}
