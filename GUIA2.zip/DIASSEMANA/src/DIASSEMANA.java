public class DIASSEMANA {
    
    public static String obtenerDiaSiguiente(String dia) 
    {        
        dia = dia.toLowerCase();
        switch (dia) {
            case "lunes":
                return "martes";
            case "martes":
                return "miércoles";
            case "miércoles":
                return "jueves";
            case "jueves":
                return "viernes";
            case "viernes":
                return "sábado";
            case "sábado":
                return "domingo";
            case "domingo":
                return "lunes";
            default:
                return "Día no válido";
        }
    }    
    public static void main(String[] args) {
        java.util.Scanner entrada = new java.util.Scanner(System.in);        
        System.out.print("Ingrese el nombre de un día de la semana: ");
        String diaHoy = entrada.nextLine();        
        String diaManana = obtenerDiaSiguiente(diaHoy);        
        System.out.println("El día de mañana es: " + diaManana);
    }
}
